
(function() {

  if (window.__telehashTopbarLoaded) return;
  window.__telehashTopbarLoaded = true;

  const BAR_HEIGHT = 115;
  const STATS_REFRESH_MS = 15000;
  const TELECACHE_POLL_MS = 2000;
  const LIGHTNING_POLL_MS = 1000;
  const GOAL_BTC = 3.125;

  const PROM_BASE = 'https://pool.256foundation.org';
  const TELECACHE_URL = 'https://dpluspl.us/api/telecacheRead';
  const LIGHTNING_URL = 'https://dpluspl.us/api/lightningRead';
  const BEST_SHARE_URL = 'https://app.dplus.plus/api/bestShare';

  const LOGO_URL = chrome.runtime.getURL('telehash-logo.png');
  const PAYMENT_SOUND_URL = chrome.runtime.getURL('sound.mp3');

  // Reuse a single Audio element so playback is instant and a previous play() can
  // be safely cut short by rewinding. (Creating a new Audio() each call sometimes
  // throws away the loaded buffer.)
  let _paymentAudio = null;

  // Try inline first — fastest, works after any user interaction. If autoplay is
  // blocked (no user gesture yet on this page), fall back to playing through the
  // extension's offscreen document (which bypasses host-page autoplay policy).
  function playPaymentSound() {
    try {
      if (!_paymentAudio) {
        _paymentAudio = new Audio(PAYMENT_SOUND_URL);
        _paymentAudio.preload = 'auto';
        _paymentAudio.volume = 0.85;
      }
      _paymentAudio.currentTime = 0;
      const p = _paymentAudio.play();
      if (p && typeof p.catch === 'function') {
        p.catch(function() {
          // Inline blocked (autoplay policy or other) — route through offscreen doc.
          try {
            chrome.runtime.sendMessage({ type: 'playPaymentSound', url: PAYMENT_SOUND_URL }, function() {
              if (chrome.runtime.lastError) { /* no-op */ }
            });
          } catch (_) {}
        });
      }
    } catch (e) {
      // Inline throw (rare) — fall back to offscreen route.
      try {
        chrome.runtime.sendMessage({ type: 'playPaymentSound', url: PAYMENT_SOUND_URL }, function() {
          if (chrome.runtime.lastError) { /* no-op */ }
        });
      } catch (_) {}
    }
  }

  // Progress / confetti state
  let onChainSats = 0;
  let lightningSats = 0;
  let onChainLoaded = false;
  let lightningLoaded = false;
  let initialLoadComplete = false;
  let currentBtcRaised = 0;

  // Payment popup state (lightning chat = payment with memo)
  let seenChatIndexes = new Set();
  let firstLightningPoll = true;

  // Confetti palette — matches teledash blue/white theme
  const confettiColors = [
    '#ffffff',
    '#58a6ff',
    '#79c0ff',
    '#38a6ff',
    '#a8d4ff',
    '#c8e1ff',
    '#1a3a6e'
  ];

  const promql = {
    totalHashrate: 'sum(rate(worker_shares_valid_total[5m]))',
    activeWorkers: 'count(sum by (btcaddress, workername) (rate(worker_shares_valid_total[5m])) > 0)',
    topCurrentHashrate: 'topk(1, sum by (btcaddress) (rate(worker_shares_valid_total[5m])))',
    highestLoyalty: 'topk(1, sum by (btcaddress) (user_shares_valid_total))',
    workersByUser: 'count by (btcaddress) (sum by (btcaddress, workername) (rate(worker_shares_valid_total[5m])) > 0)',
    totalWorkersByUser: 'count by (btcaddress) (count by (btcaddress, workername) (worker_shares_valid_total))',
    bestShareByUser: 'max by (btcaddress) (worker_best_share_ever)'
  };

  function injectTopbar() {
    if (document.getElementById('telehashTopbar')) return;

    const style = document.createElement('style');
    style.id = 'telehashTopbarStyles';
    style.textContent = `
      #telehashTopbar {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: ${BAR_HEIGHT}px;
        z-index: 2147483647;
        overflow: visible;
        color: rgba(255,255,255,.94);
        background:
          radial-gradient(560px 100px at 22% 0%, rgba(56,166,255,.28), transparent 70%),
          radial-gradient(560px 100px at 80% 0%, rgba(140,103,255,.24), transparent 70%),
          linear-gradient(180deg, rgba(7,11,20,.985), rgba(8,14,28,.97));
        box-shadow: 0 8px 30px rgba(0,0,0,.42);
        font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
        box-sizing: border-box;
        padding: 7px 20px 16px;
        display: flex;
        flex-direction: column;
        gap: 10px;
      }

      #telehashTopbar * { box-sizing: border-box; }

      #telehashConfettiLayer {
        position: fixed;
        inset: 0;
        pointer-events: none;
        overflow: hidden;
        z-index: 2147483647;
      }

      #telehashTopbar .th-row {
        flex: 0 0 auto;
        height: 53px;
        display: grid;
        grid-template-columns: 1fr 340px 1fr;
        align-items: end;
        gap: 14px;
        max-width: 1500px;
        width: 100%;
        margin-left: auto;
        margin-right: auto;
      }

      #telehashTopbar .th-side {
        display: flex;
        align-items: stretch;
        gap: 8px;
        min-width: 0;
      }

      #telehashTopbar .th-side.left {
        gap: 8px;
      }

      #telehashTopbar .th-side.left {
        justify-content: flex-start;
      }

      #telehashTopbar .th-side.right {
        justify-content: flex-end;
      }

      #telehashTopbar .th-stat {
        height: 49px;
        transform: translateY(-3px);
        width: fit-content;
        flex: 0 0 auto;
        padding: 3px 22px 5px 12px;
        border-radius: 14px;
        border: 1px solid rgba(170,220,255,.14);
        background:
          radial-gradient(120% 100% at 50% -20%, rgba(56,166,255,.20), transparent 65%),
          radial-gradient(60% 80% at 0% 100%, rgba(140,103,255,.10), transparent 70%),
          linear-gradient(180deg, rgba(255,255,255,.075) 0%, rgba(255,255,255,.02) 100%);
        box-shadow:
          inset 0 1px 0 rgba(255,255,255,.12),
          inset 0 -1px 0 rgba(0,0,0,.20),
          0 12px 28px rgba(0,0,0,.30);
        overflow: hidden;
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
        gap: 2px;
        text-align: left;
        -webkit-font-smoothing: antialiased;
      }

      #telehashTopbar .th-stat.compact {
        /* inherits fit-content sizing from .th-stat */
      }

      /* Watermark icon — faint, rotated, bottom-right of card */
      #telehashTopbar .th-bg-icon {
        position: absolute;
        right: 2px;
        bottom: -8px;
        font-size: 42px;
        font-style: normal;
        line-height: 1;
        color: rgba(255,255,255,.045);
        transform: rotate(-15deg);
        pointer-events: none;
        z-index: 0;
      }

      /* Total hashrate card's bolt icon has its own horizontal offset */
      #telehashTopbar .th-stat:not(.compact) .th-bg-icon {
        right: -2px !important;
      }

      #telehashTopbar .th-label-group,
      #telehashTopbar .th-value,
      #telehashTopbar .th-sub {
        position: relative;
        z-index: 1;
      }

      /* Horizontal layout: big avatar on the left, label + value stacked on the right */
      #telehashTopbar .th-stat.th-stat-horizontal {
        flex-direction: row;
        align-items: center;
        justify-content: flex-start;
        gap: 12px;
        padding: 1px 14px 4px 12px;
        text-align: left;
      }

      #telehashTopbar .th-stat-icon {
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      #telehashTopbar .th-stat-horizontal .th-avatar {
        width: 30px;
        height: 30px;
      }

      #telehashTopbar .th-stat-horizontal .th-avatar-placeholder {
        width: 30px;
        height: 30px;
      }

      #telehashTopbar .th-stat-horizontal .th-avatar-placeholder i {
        font-size: 13px;
      }

      #telehashTopbar .th-stat-text {
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 2px;
        gap: 5px;
        min-width: 0;
        flex: 1;
      }

      #telehashTopbar .th-stat-text .th-label {
        text-align: left;
      }

      #telehashTopbar .th-stat-text .th-sub-value {
        font-size: 16px;
        transform: translateY(-2px);
        font-weight: 800;
        line-height: 1;
        color: #fff;
        font-variant-numeric: tabular-nums;
        letter-spacing: -.01em;
        white-space: nowrap;
        text-shadow: 0 1px 2px rgba(0,0,0,.4), 0 0 14px rgba(56,166,255,.32);
      }


      #telehashTopbar .th-stat.th-clickable {
        cursor: pointer;
        transition: transform 120ms ease, border-color 120ms ease, box-shadow 120ms ease;
      }

      #telehashTopbar .th-stat.th-clickable:hover {
        transform: translateY(-1px);
        border-color: rgba(170,220,255,.28);
        box-shadow:
          inset 0 1px 0 rgba(255,255,255,.18),
          inset 0 -1px 0 rgba(0,0,0,.22),
          0 14px 32px rgba(0,0,0,.35),
          0 0 18px rgba(56,166,255,.22);
      }

      #telehashTopbar .th-stat.gold {
        border-color: rgba(255,209,102,.20);
        background:
          radial-gradient(120% 100% at 50% -20%, rgba(255,209,102,.16), transparent 65%),
          radial-gradient(60% 80% at 0% 100%, rgba(255,140,60,.08), transparent 70%),
          linear-gradient(180deg, rgba(255,255,255,.075) 0%, rgba(255,255,255,.02) 100%);
      }

      #telehashTopbar .th-stat::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(121,192,255,.55), transparent);
      }

      #telehashTopbar .th-stat.gold::before {
        background: linear-gradient(90deg, transparent, rgba(255,209,102,.60), transparent);
      }

      #telehashTopbar .th-label-group {
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 8px;
        max-width: 100%;
      }

      /* Wraps label + value vertically for left cards in row layout */
      #telehashTopbar .th-stat-text-left {
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 3px;
        flex: 0 0 auto;
        white-space: nowrap;
      }

      #telehashTopbar .th-label {
        color: rgba(170,220,255,.72);
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
        font-size: 9px;
        line-height: 1;
        letter-spacing: .22em;
        text-transform: uppercase;
        white-space: nowrap;
      }

      #telehashTopbar .th-stat.gold .th-label {
        color: rgba(255,222,150,.80);
      }

      #telehashTopbar .th-icon {
        width: 13px;
        height: 13px;
        flex-shrink: 0;
        color: #79c0ff;
        filter: drop-shadow(0 0 6px rgba(121,192,255,.50));
      }

      #telehashTopbar .th-icon.gold {
        color: #ffd166;
        filter: drop-shadow(0 0 7px rgba(255,209,102,.60));
      }

      #telehashTopbar .th-value {
        color: #ffffff;
        font-size: 20px;
        font-weight: 800;
        line-height: 1;
        white-space: nowrap;
        font-variant-numeric: tabular-nums;
        letter-spacing: -.015em;
        text-shadow:
          0 1px 2px rgba(0,0,0,.4),
          0 0 18px rgba(56,166,255,.28);
      }

      #telehashTopbar .th-stat.gold .th-value {
        text-shadow:
          0 1px 2px rgba(0,0,0,.4),
          0 0 18px rgba(255,209,102,.28);
      }

      #telehashTopbar .th-sub {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        max-width: 100%;
        min-width: 0;
        color: rgba(220,232,255,.92);
        font-size: 12px;
        line-height: 1;
      }

      #telehashTopbar .th-sub-id {
        display: flex;
        align-items: center;
        gap: 7px;
        min-width: 0;
        flex: 0 1 auto;
      }

      #telehashTopbar .th-sub-name {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
        font-weight: 500;
        letter-spacing: .01em;
      }

      #telehashTopbar .th-sub-value {
        flex: 0 0 auto;
        font-size: 16px;
        font-weight: 800;
        color: #ffffff;
        font-variant-numeric: tabular-nums;
        letter-spacing: -.01em;
        white-space: nowrap;
        text-shadow:
          0 1px 2px rgba(0,0,0,.4),
          0 0 14px rgba(56,166,255,.32);
      }

      #telehashTopbar .th-unit {
        font-size: 0.7em;
        font-weight: 700;
        color: rgba(255,255,255,.55);
        margin-left: 5px;
        letter-spacing: 0;
        text-shadow: none;
        font-variant-numeric: normal;
      }

      #telehashTopbar .th-stat.gold .th-sub-value {
        color: #ffd166;
        text-shadow: 0 0 12px rgba(255,209,102,.38);
      }

      #telehashTopbar .th-avatar {
        width: 19px;
        height: 19px;
        border-radius: 50%;
        object-fit: cover;
        background: rgba(255,255,255,.06);
        display: none;
        flex-shrink: 0;
        box-shadow:
          0 0 0 1.5px rgba(121,192,255,.55),
          0 0 12px rgba(56,166,255,.35),
          0 2px 6px rgba(0,0,0,.35);
      }

      #telehashTopbar .th-avatar.show {
        display: inline-block;
      }

      #telehashTopbar .th-avatar-placeholder {
        width: 19px;
        height: 19px;
        border-radius: 50%;
        background: rgba(255,255,255,.06);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        box-shadow:
          0 0 0 1.5px rgba(121,192,255,.45),
          0 0 12px rgba(56,166,255,.28),
          0 2px 6px rgba(0,0,0,.35);
      }

      #telehashTopbar .th-avatar-placeholder.hide {
        display: none;
      }

      #telehashTopbar .th-avatar-placeholder i {
        font-size: 10px;
        color: rgba(255,255,255,.65);
        line-height: 1;
      }

      #telehashTopbar .th-center {
        display: flex;
        align-items: center;
        justify-content: center;
        align-self: center;
        min-width: 0;
      }

      #thLogoLink { cursor: pointer; }

      #thLogo {
        height: 45px;
        margin-top: 10px;
        transform: translateY(-2px);
        max-width: 280px;
        object-fit: contain;
        image-rendering: pixelated;
        animation: thLogoPulse 3.6s ease-in-out infinite;
      }

      @keyframes thLogoPulse {
        0%, 100% {
          filter: drop-shadow(0 0 14px rgba(56,166,255,.22)) drop-shadow(0 0 30px rgba(140,103,255,.12));
        }
        50% {
          filter: drop-shadow(0 0 22px rgba(56,166,255,.42)) drop-shadow(0 0 46px rgba(140,103,255,.22));
        }
      }

      #telehashTopbar .th-progress-section {
        flex: 0 0 auto;
        position: relative;
        height: 34px;
        max-width: 1500px;
        width: 100%;
        margin-left: auto;
        margin-right: auto;
      }

      #telehashTopbar .th-progress-bg {
        position: relative;
        height: 100%;
        background: rgba(8,12,22,.85);
        border: 1px solid rgba(170,220,255,.22);
        border-radius: 4px;
        overflow: hidden;
        box-shadow: inset 0 0 14px rgba(0,0,0,.6);
      }

      #telehashTopbar .th-progress-fill {
        position: relative;
        height: 100%;
        width: 0%;
        background:
          repeating-linear-gradient(-45deg,
            rgba(255,255,255,0) 0 14px,
            rgba(255,255,255,.14) 14px 28px),
          linear-gradient(180deg, #9fd0ff 0%, #58a6ff 45%, #2f7fd0 100%);
        background-size: 56px 100%, 100% 100%;
        box-shadow:
          0 0 22px rgba(56,166,255,.55),
          inset 0 1px 0 rgba(255,255,255,.35),
          inset 0 -1px 0 rgba(0,0,0,.25);
        transition: width 2.5s cubic-bezier(0.4, 0, 0.2, 1);
        animation: thShimmer 4s linear infinite;
      }

      #telehashTopbar .th-progress-fill::after {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 18px;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,.45));
        pointer-events: none;
      }

      @keyframes thShimmer {
        0% { background-position: 0 0, 0 0; }
        100% { background-position: 56px 0, 0 0; }
      }

      #telehashTopbar .th-progress-amount {
        position: absolute;
        inset: 0;
        display: grid;
        grid-template-columns: 1fr 340px 1fr;
        gap: 14px;
        align-items: center;
        pointer-events: none;
        transform: translate(3px, -1px);
      }

      #telehashTopbar .th-progress-amount-inner {
        grid-column: 2;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        font-weight: 700;
        letter-spacing: .5px;
        text-shadow: 0 1px 3px rgba(0,0,0,.85), 0 0 10px rgba(0,0,0,.5);
      }

      #telehashTopbar .th-btc-value {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
        font-size: 16px;
        font-weight: 600;
        color: #fff;
        font-variant-numeric: tabular-nums;
        letter-spacing: 0;
        text-shadow: 0 1px 3px rgba(0,0,0,.85);
      }

      #telehashTopbar .th-btc-label {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
        font-size: 16px;
        font-weight: 600;
        color: rgba(255,255,255,.92);
        text-transform: uppercase;
        letter-spacing: .08em;
      }

      #telehashTopbar .th-goal-tag {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
        font-size: 14px;
        font-weight: 600;
        color: rgba(170,220,255,.92);
        text-transform: uppercase;
        letter-spacing: .08em;
        margin-left: 14px;
      }

      /* Hover tooltip — nostr / twitter profile card on right-side card hover */
      #thHoverTip {
        position: fixed;
        z-index: 2147483647;
        pointer-events: none;
        opacity: 0;
        transition: opacity 120ms ease;
        max-width: 320px;
        background: rgba(10,14,26,.94);
        border: 1px solid rgba(170,220,255,.22);
        border-radius: 14px;
        padding: 12px 14px;
        box-shadow: 0 18px 55px rgba(0,0,0,.6), 0 0 22px rgba(56,166,255,.18);
        color: rgba(255,255,255,.92);
        font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
        font-size: 12px;
        font-weight: 400;
        font-style: normal;
        line-height: 1.4;
        letter-spacing: normal;
        text-transform: none;
        text-align: left;
        text-indent: 0;
        word-spacing: normal;
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
      }

      #thHoverTip *:not(i):not(.fa):not(.fas):not(.fa-solid):not(.fa-regular):not(.fa-brands) {
        font-family: inherit;
        letter-spacing: normal;
        text-transform: none;
        text-indent: 0;
        word-spacing: normal;
        box-sizing: border-box;
      }

      #thHoverTip i {
        box-sizing: border-box;
      }

      #thHoverTip.show { opacity: 1; }

      #thHoverTip .th-tip-head {
        display: flex;
        align-items: center;
        gap: 12px;
        padding-bottom: 14px;
      }

      #thHoverTip .th-tip-avatar {
        width: 46px;
        height: 46px;
        border-radius: 50%;
        object-fit: cover;
        flex-shrink: 0;
        background: rgba(255,255,255,.04);
      }

      #thHoverTip .th-tip-avatar.nostr { border: 2px solid #8c67ff; }
      #thHoverTip .th-tip-avatar.twitter { border: 2px solid #79c0ff; }

      #thHoverTip .th-tip-name {
        display: flex;
        flex-direction: column;
        min-width: 0;
        gap: 2px;
      }

      #thHoverTip .th-tip-display {
        font-weight: 800;
        color: #fff;
        font-size: 15px;
        letter-spacing: -.01em;
        word-break: break-word;
      }

      #thHoverTip .th-tip-kind {
        font-size: 9px;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-weight: 700;
        letter-spacing: 1.4px;
        text-transform: uppercase;
      }

      #thHoverTip .th-tip-kind.nostr { color: #8c67ff; }
      #thHoverTip .th-tip-kind.twitter { color: #79c0ff; }

      #thHoverTip .th-tip-bio {
        font-size: 12px;
        color: rgba(255,255,255,.62);
        margin-top: 0;
        line-height: 1.35;
        word-break: break-word;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }

      #thHoverTip .th-tip-row {
        font-size: 12px;
        margin-top: 2px;
        line-height: 1.25;
        word-break: break-word;
        display: flex;
        align-items: center;
        gap: 6px;
      }

      #thHoverTip .th-tip-bio + .th-tip-row {
        margin-top: 8px;
      }

      #thHoverTip .th-tip-row.nip05 { color: #a78bfa; font-family: ui-monospace, monospace; }
      #thHoverTip .th-tip-row.website { color: #79c0ff; }
      #thHoverTip .th-tip-row.lightning { color: #facc15; }

      #thHoverTip .th-tip-row .ic {
        font-size: 11px;
        width: 12px;
        text-align: center;
        flex-shrink: 0;
        opacity: .8;
        line-height: 1;
      }

      #thHoverTip .th-tip-foot {
        margin-top: 12px;
        padding-top: 10px;
        border-top: 1px solid rgba(255,255,255,.12);
        font-size: 11px;
        color: rgba(255,255,255,.85);
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: wrap;
        min-width: 0;
      }

      #thHoverTip .th-tip-foot .dot {
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #3fb950;
        flex-shrink: 0;
        font-size: 0;
        line-height: 0;
        vertical-align: middle;
      }

      #thHoverTip .th-tip-foot .dot.inactive {
        background: #f85149;
      }

      /* dash.256f.org root tightens this gap — add 4px breathing room */
      #thHoverTip.th-dash-root .th-tip-foot .dot {
        margin-right: 4px;
      }

      #thHoverTip .th-tip-foot .sep {
        opacity: .5;
      }

      /* Payment popup — formatted like a teledash lightning-chat row */
      #thPaymentPopup {
        position: fixed;
        right: 18px;
        top: ${BAR_HEIGHT + 12}px;
        width: 360px;
        z-index: 2147483647;
        display: none;
        border-radius: 18px;
        border: 1px solid rgba(121,192,255,.55);
        background:
          radial-gradient(500px 180px at 0% 0%, rgba(56,166,255,.22), transparent 65%),
          linear-gradient(180deg, rgba(12,18,34,.98), rgba(8,10,18,.98));
        color: rgba(255,255,255,.95);
        box-shadow: 0 18px 70px rgba(0,0,0,.55), 0 0 22px rgba(56,166,255,.32);
        overflow: hidden;
        font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
        transition: opacity .6s ease;
      }

      #thPaymentPopup.show {
        display: block;
        animation: thPop .18s ease-out;
      }

      #thPaymentPopup.fading {
        opacity: 0;
      }

      @keyframes thPop {
        from { transform: translateY(-8px) scale(.97); opacity: 0; }
        to { transform: translateY(0) scale(1); opacity: 1; }
      }

      #thPaymentPopup .th-pp-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 11px 14px;
        border-bottom: 1px solid rgba(255,255,255,.10);
        color: #79c0ff;
        font-weight: 800;
        font-size: 13px;
        letter-spacing: .04em;
        text-transform: none;
      }

      #thPaymentPopup .th-pp-head .bolt {
        color: #79c0ff;
        filter: drop-shadow(0 0 6px rgba(121,192,255,.55));
        margin-right: 6px;
      }

      #thPpClose {
        appearance: none;
        border: 0;
        background: transparent;
        color: rgba(255,255,255,.7);
        font-size: 22px;
        cursor: pointer;
        line-height: 1;
        padding: 0;
      }

      #thPaymentPopup .th-pp-body {
        padding: 14px 14px 12px;
        font-size: 14px;
        line-height: 1.4;
        word-wrap: break-word;
      }

      #thPaymentPopup .th-chat-user {
        color: #8ba3c7;
        font-weight: 600;
      }

      #thPaymentPopup .th-chat-user::after {
        content: ':';
        color: rgba(255,255,255,.45);
        margin-right: 4px;
      }

      #thPaymentPopup .th-chat-text {
        color: rgba(255,255,255,.96);
      }

      #thPaymentPopup .th-chat-amount {
        display: inline-block;
        font-size: 11px;
        font-weight: 700;
        margin-left: 8px;
        color: #79c0ff;
        background: rgba(121,192,255,.15);
        padding: 2px 8px;
        border-radius: 999px;
        text-shadow: 0 0 6px rgba(121,192,255,.5);
        white-space: nowrap;
        vertical-align: 1px;
      }

      #thPaymentPopup .th-chat-amount .bolt {
        font-size: 10px;
        margin-right: 3px;
        color: #79c0ff;
      }

      #thPaymentPopup .th-chat-link {
        color: #79c0ff;
        word-break: break-all;
        text-decoration: underline;
        text-decoration-color: rgba(121,192,255,.45);
      }

      #thPaymentPopup .th-img-link {
        display: block;
        margin-top: 6px;
      }

      #thPaymentPopup .th-chat-img {
        display: block;
        max-width: 100%;
        max-height: 200px;
        border-radius: 6px;
        margin: 0 auto;
        border: 1px solid rgba(255,255,255,.08);
      }

      #thPaymentPopup .th-pp-timer {
        height: 4px;
        background: rgba(255,255,255,.10);
      }

      #thPpTimerFill {
        display: block;
        height: 100%;
        width: 100%;
        background: linear-gradient(90deg, #79c0ff, #58a6ff);
        transition: width .25s linear;
      }

      .th-confetti {
        position: fixed;
        top: -18px;
        width: 8px;
        height: 14px;
        border-radius: 2px;
        opacity: .95;
        pointer-events: none;
        z-index: 2147483647;
        animation: thConfettiFall var(--fall-ms) linear forwards;
      }

      @keyframes thConfettiFall {
        0% { transform: translate3d(0, -30px, 0) rotate(0deg); opacity: 1; }
        100% { transform: translate3d(var(--drift), 115vh, 0) rotate(780deg); opacity: 0; }
      }

      @media (max-width: 1600px) {
        #telehashTopbar .th-row { grid-template-columns: 1fr 280px 1fr; }
        #telehashTopbar .th-stat { min-width: unset; padding: 1px 14px 4px 12px; }
        #telehashTopbar .th-value { font-size: 20px; }
      }

      @media (max-width: 1200px) {
        #telehashTopbar .th-sub { display: none; }
        #telehashTopbar .th-stat { height: 58px; padding: 8px 12px; }
      }
    `;

    const root = document.createElement('div');
    root.id = 'telehashTopbar';

    root.innerHTML = `
      <div class="th-row">
        <div class="th-side left">
          <div class="th-stat" style="padding-right:20px">
            <i class="fa-solid fa-bolt th-bg-icon" aria-hidden="true"></i>
            <div class="th-label-group">
              <div class="th-label">total hashrate</div>
            </div>
            <div class="th-value" id="thTotalHashrate" style="padding-left:6px">...</div>
          </div>
          <div class="th-stat compact">
            <i class="fa-solid fa-microchip th-bg-icon" aria-hidden="true"></i>
            <div class="th-label-group">
              <div class="th-label">total workers</div>
            </div>
            <div class="th-value" id="thWorkers" style="padding-left:6px">...</div>
          </div>
          <div class="th-stat compact">
            <i class="fa-solid fa-cube th-bg-icon" aria-hidden="true"></i>
            <div class="th-label-group">
              <div class="th-label">blocks found</div>
            </div>
            <div class="th-value" id="thBlocksFound" style="padding-left:6px">...</div>
          </div>
        </div>

        <div class="th-center">
          <a id="thLogoLink" href="https://dash.256f.org/" style="display:inline-flex;align-items:center;justify-content:center;text-decoration:none;"><img id="thLogo" src="${LOGO_URL}" alt="telehash"></a>
        </div>

        <div class="th-side right">
          <div class="th-stat th-stat-horizontal">
            <div class="th-stat-icon">
              <img class="th-avatar" id="thTopHashrateAvatar" alt="">
              <span class="th-avatar-placeholder" id="thTopHashratePlaceholder"><i class="fa-solid fa-hammer" aria-hidden="true"></i></span>
            </div>
            <div class="th-stat-text">
              <div class="th-label">top hasher</div>
              <span class="th-sub-value" id="thTopHashrate">...</span>
            </div>
            <span class="th-sub-name" id="thTopHashrateWho" style="display:none"></span>
          </div>
          <div class="th-stat th-stat-horizontal">
            <div class="th-stat-icon">
              <img class="th-avatar" id="thHighestDifficultyAvatar" alt="">
              <span class="th-avatar-placeholder" id="thHighestDifficultyPlaceholder"><i class="fa-solid fa-hammer" aria-hidden="true"></i></span>
            </div>
            <div class="th-stat-text">
              <div class="th-label">best share</div>
              <span class="th-sub-value" id="thHighestDifficulty">...</span>
            </div>
            <span class="th-sub-name" id="thHighestDifficultyWho" style="display:none"></span>
          </div>
          <div class="th-stat th-stat-horizontal">
            <div class="th-stat-icon">
              <img class="th-avatar" id="thHighestLoyaltyAvatar" alt="">
              <span class="th-avatar-placeholder" id="thHighestLoyaltyPlaceholder"><i class="fa-solid fa-hammer" aria-hidden="true"></i></span>
            </div>
            <div class="th-stat-text">
              <div class="th-label">most loyal</div>
              <span class="th-sub-value" id="thHighestLoyalty">...</span>
            </div>
            <span class="th-sub-name" id="thHighestLoyaltyWho" style="display:none"></span>
          </div>
        </div>
      </div>

      <div class="th-progress-section">
        <div class="th-progress-bg">
          <div class="th-progress-fill" id="thProgressFill"></div>
          <div class="th-progress-amount">
            <div class="th-progress-amount-inner">
              <span class="th-btc-value" id="thBtcValue">0.00000000</span>
              <span class="th-btc-label">BTC raised</span>
            </div>
          </div>
        </div>
      </div>
    `;

    const confetti = document.createElement('div');
    confetti.id = 'telehashConfettiLayer';

    const popup = document.createElement('div');
    popup.id = 'thPaymentPopup';
    popup.innerHTML = `
      <div class="th-pp-head">
        <span><span class="bolt">⚡</span>New Lightning payment!</span>
        <button type="button" id="thPpClose">×</button>
      </div>
      <div class="th-pp-body" id="thPpBody"></div>
      <div class="th-pp-timer"><span id="thPpTimerFill"></span></div>
    `;

    const hoverTip = document.createElement('div');
    hoverTip.id = 'thHoverTip';

    // dash.256f.org root page renders the dot slightly tighter against "active" —
    // bump margin-right by 2px there to match other sites visually.
    try {
      const isDashRoot = window.location.hostname === 'dash.256f.org' &&
                         (window.location.pathname === '/' || window.location.pathname === '');
      if (isDashRoot) hoverTip.classList.add('th-dash-root');
    } catch (e) {}

    // Load Font Awesome from the extension's own bundle — no network call, no
    // dependency on the host page's CSP. Same 6.5.2 version as index.html.
    if (!document.getElementById('thFontAwesome')) {
      const faLink = document.createElement('link');
      faLink.id = 'thFontAwesome';
      faLink.rel = 'stylesheet';
      faLink.href = chrome.runtime.getURL('font-awesome/css/all.min.css');
      document.documentElement.appendChild(faLink);
    }

    document.documentElement.appendChild(style);
    document.body.appendChild(root);
    document.body.appendChild(confetti);
    document.body.appendChild(popup);
    document.body.appendChild(hoverTip);

    document.getElementById('thPpClose').addEventListener('click', hidePaymentPopup);

    setupCardInteractions();

    pushPageDown();
  }

  function pushPageDown() {
    const html = document.documentElement;
    const body = document.body;
    const host = window.location.hostname;
    const isHashdash =
      host === 'dash.256f.org' ||
      document.title.includes('Hashdash') ||
      document.querySelector('.wrap .grid .overview');

    if (html.dataset.telehashPaddingApplied) return;

    if (isHashdash) {
      const app = document.querySelector('.wrap') || body.firstElementChild;
      if (app && app.id !== 'telehashTopbar') {
        const currentMargin = parseInt(window.getComputedStyle(app).marginTop, 10) || 0;
        app.style.marginTop = (currentMargin + BAR_HEIGHT) + 'px';
      }
      html.dataset.telehashPaddingApplied = 'true';
      return;
    }

    const currentPadding = parseInt(window.getComputedStyle(html).paddingTop, 10) || 0;
    html.style.paddingTop = (currentPadding + BAR_HEIGHT) + 'px';
    html.dataset.telehashPaddingApplied = 'true';
  }

  // ---------------- Prometheus stats ----------------

  async function promQuery(query) {
    const res = await fetch(PROM_BASE + '/api/v1/query', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: 'query=' + encodeURIComponent(query)
    });

    if (!res.ok) throw new Error('prometheus ' + res.status);
    return await res.json();
  }

  function resultSeries(resp) {
    if (!resp || resp.status !== 'success' || !resp.data) return [];
    return resp.data.result || [];
  }

  function scalarValue(resp) {
    const r = resultSeries(resp);
    if (!r.length || !r[0].value) return NaN;
    const value = parseFloat(r[0].value[1]);
    return Number.isFinite(value) ? value : NaN;
  }

  async function firstPromSeries(queries) {
    for (const q of queries) {
      try {
        const resp = await promQuery(q);
        const s = resultSeries(resp);
        if (s.length) return s;
      } catch (err) {}
    }
    return [];
  }

  async function firstPromScalar(queries) {
    for (const q of queries) {
      try {
        const resp = await promQuery(q);
        const v = scalarValue(resp);
        if (Number.isFinite(v)) return v;
      } catch (err) {}
    }
    return NaN;
  }

  function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  }

  // Sets a value like "707 TH/s" but renders the unit in a dimmer/smaller span
  function setValueWithUnit(id, str) {
    const el = document.getElementById(id);
    if (!el) return;
    if (!str) { el.textContent = '—'; return; }
    const idx = String(str).indexOf(' ');
    if (idx === -1) {
      el.textContent = str;
      return;
    }
    const num = String(str).slice(0, idx);
    const unit = String(str).slice(idx + 1);
    el.textContent = num;
    const span = document.createElement('span');
    span.className = 'th-unit';
    span.textContent = unit;
    el.appendChild(span);
  }

  function formatHashrate(hps) {
    if (!Number.isFinite(hps) || hps <= 0) return '0 H/s';
    const units = [['EH/s',1e18,1], ['PH/s',1e15,1], ['TH/s',1e12,0], ['GH/s',1e9,0], ['MH/s',1e6,0], ['KH/s',1e3,0]];
    for (const [unit, div, dec] of units) {
      if (hps >= div) return (hps / div).toFixed(dec) + ' ' + unit;
    }
    return hps.toFixed(0) + ' H/s';
  }

  function formatDifficulty(diff) {
    if (!Number.isFinite(diff) || diff <= 0) return '—';
    if (diff >= 1e12) return (diff / 1e12).toFixed(0) + ' T';
    if (diff >= 1e9) return (diff / 1e9).toFixed(0) + ' G';
    if (diff >= 1e6) return (diff / 1e6).toFixed(0) + ' M';
    if (diff >= 1e3) return (diff / 1e3).toFixed(0) + ' K';
    return diff.toFixed(0);
  }

  // Compact form for tooltips: 1 decimal, no space between number and unit (e.g. "5.9G")
  function formatDifficultyCompact(diff) {
    if (!Number.isFinite(diff) || diff <= 0) return '—';
    if (diff >= 1e12) return (diff / 1e12).toFixed(1) + 'T';
    if (diff >= 1e9) return (diff / 1e9).toFixed(1) + 'G';
    if (diff >= 1e6) return (diff / 1e6).toFixed(1) + 'M';
    if (diff >= 1e3) return (diff / 1e3).toFixed(1) + 'K';
    return diff.toFixed(0);
  }

  function formatHashCount(n) {
    if (!Number.isFinite(n) || n <= 0) return '—';
    if (n >= 1e18) return (n / 1e18).toFixed(0) + ' E';
    if (n >= 1e15) return (n / 1e15).toFixed(0) + ' P';
    if (n >= 1e12) return (n / 1e12).toFixed(0) + ' T';
    if (n >= 1e9) return (n / 1e9).toFixed(0) + ' G';
    if (n >= 1e6) return (n / 1e6).toFixed(0) + ' M';
    if (n >= 1e3) return (n / 1e3).toFixed(0) + ' K';
    return n.toFixed(0);
  }

  function displayName(value) {
    if (!value) return '';
    value = String(value);
    if (value.length <= 20) return value;
    return value.slice(0, 9) + '…' + value.slice(-6);
  }

  function metricName(metric) {
    return (
      metric.workername ||
      metric.worker ||
      metric.rig ||
      metric.btcaddress ||
      metric.address ||
      ''
    );
  }

  async function fetchBestShare() {
    try {
      const res = await fetch(BEST_SHARE_URL, { cache: 'no-store' });
      if (!res.ok) return null;
      const json = await res.json();
      const result = json && json.data && json.data.result && json.data.result[0];
      if (!result || !result.value) return null;
      const value = parseFloat(result.value[1]);
      if (!Number.isFinite(value)) return null;
      const m = result.metric || {};
      let who = m.workername || 'unknown';
      const user = m.btcaddress || m.username || '';
      if (who.toLowerCase() === 'unnamed' && user) who = user;
      return { value, who, fallback: user };
    } catch (err) {
      return null;
    }
  }

  // Per-user maps populated each refresh, keyed by btcaddress
  const userWorkerCount = new Map();      // currently active workers (5m)
  const userTotalWorkerCount = new Map(); // all-time distinct workers
  const userBestShare = new Map();

  async function refreshStats() {
    try {
      const totalHashrate = await firstPromScalar([promql.totalHashrate]);
      setValueWithUnit('thTotalHashrate', formatHashrate(totalHashrate));

      const workers = await firstPromScalar([promql.activeWorkers]);
      setText('thWorkers', Number.isFinite(workers) ? workers.toLocaleString('en-US', { maximumFractionDigits: 0 }) : '—');

      // Per-user worker counts (currently active in 5m)
      userWorkerCount.clear();
      const workersByUser = await firstPromSeries([promql.workersByUser]);
      workersByUser.forEach(s => {
        const addr = s.metric && s.metric.btcaddress;
        const n = s.value ? parseFloat(s.value[1]) : NaN;
        if (addr && Number.isFinite(n)) userWorkerCount.set(addr, n);
      });

      // Per-user total worker counts (all-time, fallback when user is currently inactive)
      userTotalWorkerCount.clear();
      const totalWorkersByUser = await firstPromSeries([promql.totalWorkersByUser]);
      totalWorkersByUser.forEach(s => {
        const addr = s.metric && s.metric.btcaddress;
        const n = s.value ? parseFloat(s.value[1]) : NaN;
        if (addr && Number.isFinite(n)) userTotalWorkerCount.set(addr, n);
      });

      // Per-user best share
      userBestShare.clear();
      const bestByUser = await firstPromSeries([promql.bestShareByUser]);
      bestByUser.forEach(s => {
        const addr = s.metric && s.metric.btcaddress;
        const v = s.value ? parseFloat(s.value[1]) : NaN;
        if (addr && Number.isFinite(v)) userBestShare.set(addr, v);
      });

      const best = await fetchBestShare();
      if (best) {
        setValueWithUnit('thHighestDifficulty', formatDifficulty(best.value));
        setUserDisplay('thHighestDifficultyWho', 'thHighestDifficultyAvatar', best.who, best.fallback);
      }

      const topHash = await firstPromSeries([promql.topCurrentHashrate]);
      if (topHash.length) {
        const hps = topHash[0].value ? parseFloat(topHash[0].value[1]) : NaN;
        const m = topHash[0].metric || {};
        setValueWithUnit('thTopHashrate', formatHashrate(hps));
        setUserDisplay('thTopHashrateWho', 'thTopHashrateAvatar', metricName(m), m.btcaddress || '');
      }

      const loyalty = await firstPromSeries([promql.highestLoyalty]);
      if (loyalty.length) {
        const hashes = loyalty[0].value ? parseFloat(loyalty[0].value[1]) : NaN;
        const m = loyalty[0].metric || {};
        setValueWithUnit('thHighestLoyalty', formatHashCount(hashes));
        setUserDisplay('thHighestLoyaltyWho', 'thHighestLoyaltyAvatar', metricName(m), m.btcaddress || '');
      }

    } catch (err) {
      console.error('telehash topbar stats:', err);
    }
  }

  // ---------------- Balance + progress ----------------

  function animateCountUp(startVal, endVal, duration, callback) {
    const startTime = performance.now();
    const diff = endVal - startVal;

    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = startVal + (diff * eased);
      callback(current);
      if (progress < 1) requestAnimationFrame(update);
    }

    requestAnimationFrame(update);
  }

  function updateProgress(newBtc) {
    const bothLoaded = onChainLoaded && lightningLoaded;

    if (newBtc > currentBtcRaised) {
      if (initialLoadComplete) {
        launchConfetti();
        playPaymentSound();
      }

      animateCountUp(currentBtcRaised, newBtc, 2500, function(val) {
        setText('thBtcValue', val.toFixed(8));
      });

      const percent = Math.max(0, Math.min(100, (newBtc / GOAL_BTC) * 100));
      const fill = document.getElementById('thProgressFill');
      if (fill) fill.style.width = percent.toFixed(4) + '%';

      currentBtcRaised = newBtc;
    } else if (newBtc !== currentBtcRaised) {
      // Balance dropped (refund / adjustment) — update silently
      setText('thBtcValue', newBtc.toFixed(8));
      const percent = Math.max(0, Math.min(100, (newBtc / GOAL_BTC) * 100));
      const fill = document.getElementById('thProgressFill');
      if (fill) fill.style.width = percent.toFixed(4) + '%';
      currentBtcRaised = newBtc;
    }

    if (bothLoaded && !initialLoadComplete) {
      initialLoadComplete = true;
    }
  }

  function recomputeTotal() {
    const totalSats = onChainSats + lightningSats;
    const totalBtc = totalSats / 1e8;
    updateProgress(totalBtc);
  }

  async function pollTelecache() {
    try {
      const res = await fetch(TELECACHE_URL, { cache: 'no-store' });
      if (!res.ok) return;
      const json = await res.json();

      if (!json || !json.success || !json.data) return;
      const data = json.data;

      if (typeof data.balance === 'number' && data.balance >= 0) {
        onChainSats = data.balance;
        onChainLoaded = true;
        recomputeTotal();
      }

      if (typeof data.blocksFound === 'number') {
        setText('thBlocksFound', String(Math.max(0, data.blocksFound - 1)));
      }
    } catch (err) {
      console.debug('telehash topbar telecache:', err);
    }
  }

  // ---------------- Lightning chat = payment-with-memo ----------------

  function sanitize(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Image hosts we trust enough to render inline inside the payment popup UI.
  // Avoid prefix-match wildcards (e.g. `imgproxy.`) — those let any attacker-controlled
  // subdomain look trusted and host phishing imagery inside our trusted popup chrome.
  const IMAGE_HOSTS = /^https?:\/\/(encrypted-tbn\d*\.gstatic\.com\/images|i\.imgur\.com|pbs\.twimg\.com|cdn\.nostr\.build|image\.nostr\.build|nostr\.build\/i|void\.cat\/d|imgproxy\.iris\.to|imgproxy\.snort\.social|imgproxy\.coracle\.social)/i;
  const IMAGE_EXT = /\.(jpe?g|png|gif|webp|bmp|svg)$/i;

  // Render a raw text string into HTML with URLs linkified and image URLs
  // inline-rendered as <img>. Mirrors teledash's chat-message renderer.
  // Returns { html, hasImage, isImageOnly }.
  function renderMessageHtml(rawText) {
    let message = sanitize(rawText).replace(/&quot;/g, '');

    let working = message
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"');

    const urlRegex = /(https?:\/\/[^\s<>"']+)/gi;
    const urls = [];
    let m;
    while ((m = urlRegex.exec(working)) !== null) urls.push(m[1]);

    // Unwrap Reddit media proxy URLs
    for (let i = 0; i < urls.length; i++) {
      try {
        const u = new URL(urls[i]);
        if (u.hostname.endsWith('reddit.com') && u.pathname === '/media' && u.searchParams.has('url')) {
          const realUrl = u.searchParams.get('url');
          message = message.replace(sanitize(urls[i]), sanitize(realUrl));
          urls[i] = realUrl;
        }
      } catch (e) {}
    }

    let hasImage = false;
    urls.forEach(function(url) {
      // Defense-in-depth: even though the URL regex already restricts to http(s)://,
      // run through safeUrl() so any future regex relaxation can't sneak a bad scheme in.
      const validated = safeUrl(url);
      if (!validated) return;
      const escapedUrl = sanitize(validated);
      const pathOnly = validated.split('?')[0].split('#')[0];
      const isImage = IMAGE_EXT.test(pathOnly) || IMAGE_HOSTS.test(validated);

      if (isImage) {
        hasImage = true;
        const imgHtml = `<a href="${escapedUrl}" target="_blank" rel="noopener noreferrer" class="th-img-link"><img src="${escapedUrl}" class="th-chat-img"></a>`;
        message = message.replace(sanitize(url), imgHtml);
      } else {
        const linkHtml = `<a href="${escapedUrl}" target="_blank" rel="noopener noreferrer" class="th-chat-link">${escapedUrl}</a>`;
        message = message.replace(sanitize(url), linkHtml);
      }
    });

    const isImageOnly = hasImage && /^\s*<a [^>]*class="th-img-link"[^>]*><img [^>]*><\/a>\s*$/.test(message);

    return { html: message, hasImage, isImageOnly };
  }

  function splitUserAndMessage(rawMemo) {
    const memo = (rawMemo || '').trim();
    if (!memo) return { user: 'anon', text: '' };

    // URLs at the start: don't split on ':'
    if (/^["']?https?:\/\//i.test(memo) || /^["']?www\./i.test(memo)) {
      return { user: 'anon', text: memo };
    }

    if (memo.includes(':')) {
      const idx = memo.indexOf(':');
      const user = memo.slice(0, idx).trim();
      const text = memo.slice(idx + 1).trim();
      if (user && text) return { user, text };
    }

    return { user: 'anon', text: memo };
  }

  function showPaymentPopup(msg) {
    const popup = document.getElementById('thPaymentPopup');
    const body = document.getElementById('thPpBody');
    const fill = document.getElementById('thPpTimerFill');
    if (!popup || !body || !fill) return;

    let memo = (msg.memo || '').trim();
    if (memo.startsWith('| Comment:')) memo = memo.slice(10).trim();
    if (memo.startsWith('|')) memo = memo.slice(1).trim();
    if (!memo) return; // skip empty memos like teledash does

    const { user, text } = splitUserAndMessage(memo);
    const safeUser = sanitize(user).replace(/&quot;/g, '');
    const rendered = renderMessageHtml(text);

    const amount = Number(msg.amount);
    const amountBadge = (Number.isFinite(amount) && amount >= 1)
      ? `<span class="th-chat-amount"><span class="bolt">⚡</span>${amount.toLocaleString()}</span>`
      : '';

    let bodyHtml;
    if (rendered.isImageOnly) {
      // user [badge] then image below
      bodyHtml = `<span class="th-chat-user">${safeUser}</span>${amountBadge}<span class="th-chat-text"> ${rendered.html}</span>`;
    } else if (rendered.hasImage) {
      // text + image: badge after text, image below
      const imgMatch = rendered.html.match(/(<a [^>]*class="th-img-link"[^>]*><img [^>]*><\/a>)/);
      const imgPart = imgMatch ? imgMatch[1] : '';
      const textPart = imgMatch ? rendered.html.replace(imgMatch[1], '').trim() : rendered.html;
      bodyHtml = `<span class="th-chat-user">${safeUser}</span><span class="th-chat-text"> ${textPart}</span>${amountBadge}<span class="th-chat-text">${imgPart}</span>`;
    } else {
      bodyHtml = `<span class="th-chat-user">${safeUser}</span><span class="th-chat-text"> ${rendered.html}</span>${amountBadge}`;
    }

    body.innerHTML = bodyHtml;

    // Hide broken images (CSP-safe alternative to inline onerror)
    body.querySelectorAll('img.th-chat-img').forEach(function(img) {
      img.addEventListener('error', function() {
        const a = img.closest('a.th-img-link');
        if (a) a.style.display = 'none';
        else img.style.display = 'none';
      });
    });

    popup.classList.remove('fading');
    popup.classList.add('show');

    // Reset timer fill to 100% before transition restarts
    fill.style.transition = 'none';
    fill.style.width = '100%';
    void fill.offsetWidth;
    fill.style.transition = '';

    const duration = 30000;
    const started = Date.now();

    clearTimeout(popup._thHide);
    clearInterval(popup._thTick);

    popup._thTick = setInterval(function() {
      const elapsed = Date.now() - started;
      const remaining = Math.max(0, 1 - elapsed / duration);
      fill.style.width = (remaining * 100) + '%';
      if (remaining <= 0) clearInterval(popup._thTick);
    }, 250);

    popup._thHide = setTimeout(function() {
      popup.classList.add('fading');
      setTimeout(hidePaymentPopup, 650);
    }, duration);
  }

  function hidePaymentPopup() {
    const popup = document.getElementById('thPaymentPopup');
    if (!popup) return;
    popup.classList.remove('show');
    popup.classList.remove('fading');
    clearTimeout(popup._thHide);
    clearInterval(popup._thTick);
  }

  async function pollLightning() {
    try {
      const res = await fetch(LIGHTNING_URL, { cache: 'no-store' });
      if (!res.ok) return;
      const json = await res.json();

      if (!json) return;

      if (typeof json.total_money === 'number') {
        lightningSats = json.total_money;
        lightningLoaded = true;
        recomputeTotal();
      }

      if (Array.isArray(json.chats) && json.chats.length > 0) {
        const newOnes = [];
        for (const msg of json.chats) {
          if (msg.index == null) continue;
          if (seenChatIndexes.has(msg.index)) continue;
          seenChatIndexes.add(msg.index);
          if (!firstLightningPoll) newOnes.push(msg);
        }

        // Show the most recent new message (by index = msg arrival order).
        if (newOnes.length) {
          newOnes.sort((a, b) => (a.index || 0) - (b.index || 0));
          showPaymentPopup(newOnes[newOnes.length - 1]);
          playPaymentSound();
        }

        firstLightningPoll = false;
      }
    } catch (err) {
      console.debug('telehash topbar lightning:', err);
    }
  }

  // ---------------- Identity resolution (npub / NIP-05 / Twitter) ----------------

  const profileCache = new Map();      // hex_pubkey -> profile
  const idToPubkey = new Map();        // identifier -> hex_pubkey
  const identityCache = new Map();     // identifier -> Promise<{ displayName, avatarUrl }>

  const PRIMAL_CACHE_URL = 'wss://cache2.primal.net/v1';
  let primalWs = null;
  let primalReady = false;
  const primalPending = new Map();
  let primalSubCounter = 0;
  let primalBatchQueue = [];
  let primalBatchScheduled = false;

  function ensurePrimalWs() {
    if (primalWs && (primalWs.readyState === WebSocket.OPEN || primalWs.readyState === WebSocket.CONNECTING)) return;
    primalReady = false;
    try {
      primalWs = new WebSocket(PRIMAL_CACHE_URL);
    } catch (e) {
      primalWs = null;
      return;
    }
    primalWs.onopen = () => { primalReady = true; };
    primalWs.onclose = () => { primalReady = false; };
    primalWs.onerror = () => { primalReady = false; };
    primalWs.onmessage = (evt) => {
      try {
        const msg = JSON.parse(evt.data);
        const subId = msg[1];
        const pending = primalPending.get(subId);
        if (!pending) return;
        if (msg[0] === 'EVENT') {
          const event = msg[2];
          if (event.kind === 0) {
            try {
              const profile = JSON.parse(event.content);
              if (event.pubkey) pending.profiles.set(event.pubkey, profile);
            } catch (e) {}
          }
        } else if (msg[0] === 'EOSE') {
          clearTimeout(pending.timer);
          primalPending.delete(subId);
          pending.resolve(pending.profiles);
        }
      } catch (e) {}
    };
  }

  function fetchPrimalProfile(hexPubkey) {
    if (profileCache.has(hexPubkey)) return Promise.resolve(profileCache.get(hexPubkey));
    return new Promise((resolve) => {
      primalBatchQueue.push({ hex: hexPubkey, resolve });
      if (!primalBatchScheduled) {
        primalBatchScheduled = true;
        Promise.resolve().then(flushPrimalBatch);
      }
    });
  }

  function flushPrimalBatch() {
    primalBatchScheduled = false;
    const batch = primalBatchQueue.splice(0);
    if (batch.length === 0) return;

    const byHex = new Map();
    for (const item of batch) {
      if (!byHex.has(item.hex)) byHex.set(item.hex, []);
      byHex.get(item.hex).push(item.resolve);
    }

    const needed = [];
    for (const [hex, resolvers] of byHex) {
      if (profileCache.has(hex)) {
        resolvers.forEach(r => r(profileCache.get(hex)));
      } else {
        needed.push(hex);
      }
    }
    if (needed.length === 0) return;

    ensurePrimalWs();
    if (!primalWs) {
      needed.forEach(hex => (byHex.get(hex) || []).forEach(r => r(null)));
      return;
    }

    const subId = 'b_' + (++primalSubCounter);
    const finish = (profiles) => {
      for (const hex of needed) {
        const profile = profiles.get(hex) || null;
        if (profile) profileCache.set(hex, profile);
        (byHex.get(hex) || []).forEach(r => r(profile));
      }
    };

    const timer = setTimeout(() => {
      const p = primalPending.get(subId);
      primalPending.delete(subId);
      if (p) finish(p.profiles);
      else needed.forEach(hex => (byHex.get(hex) || []).forEach(r => r(null)));
    }, 5000);

    primalPending.set(subId, { profiles: new Map(), resolve: finish, timer });

    const send = () => {
      try {
        primalWs.send(JSON.stringify(['REQ', subId, { cache: ['user_infos', { pubkeys: needed }] }]));
      } catch (e) {
        clearTimeout(timer);
        primalPending.delete(subId);
        needed.forEach(hex => (byHex.get(hex) || []).forEach(r => r(null)));
      }
    };
    if (primalReady) send();
    else primalWs.addEventListener('open', send, { once: true });
  }

  async function resolveNIP05(fullname) {
    if (idToPubkey.has(fullname)) return idToPubkey.get(fullname);
    try {
      const [name, domain] = fullname.split('@');
      if (!name || !domain) return null;
      // Strict domain validation: letters, digits, dots, dashes only. Prevents users
      // from forcing the browser to GET arbitrary URLs via crafted NIP-05 identifiers
      // (e.g. workername "foo@evil.com/x" → SSRF/tracking).
      if (!/^[a-zA-Z0-9.-]+$/.test(domain) || domain.length > 253) return null;
      if (!/^[a-zA-Z0-9._+-]+$/.test(name) || name.length > 64) return null;
      const res = await fetch(`https://${domain}/.well-known/nostr.json?name=${encodeURIComponent(name)}`, { cache: 'no-store' });
      if (!res.ok) return null;
      const data = await res.json();
      const pubkey = data && data.names && data.names[name];
      if (pubkey) {
        idToPubkey.set(fullname, pubkey);
        return pubkey;
      }
    } catch (e) {}
    return null;
  }

  function extractTwitterHandle(s) {
    if (!s) return null;
    const match = String(s).match(/^@([A-Za-z0-9_]{1,15})$/);
    return match ? match[1] : null;
  }

  function getTwitterAvatarUrl(handle) {
    const clean = String(handle).replace(/[^A-Za-z0-9_]/g, '').slice(0, 15);
    return clean ? `https://unavatar.io/twitter/${encodeURIComponent(clean)}` : null;
  }

  function robohashAvatar(seed) {
    return `https://robohash.org/${encodeURIComponent(seed)}?set=set1&size=64x64`;
  }

  function npubToHex(npub) {
    try {
      if (window.NostrTools && window.NostrTools.nip19) {
        const decoded = window.NostrTools.nip19.decode(npub);
        if (decoded && decoded.data) return decoded.data;
      }
    } catch (e) {}
    return null;
  }

  function resolveIdentity(identifier) {
    if (!identifier) return Promise.resolve(null);
    identifier = String(identifier).trim();
    if (!identifier) return Promise.resolve(null);

    if (identityCache.has(identifier)) return identityCache.get(identifier);

    const promise = (async () => {
      // Twitter handle
      const twitter = extractTwitterHandle(identifier);
      if (twitter) {
        return {
          displayName: '@' + twitter,
          avatarUrl: getTwitterAvatarUrl(twitter)
        };
      }

      // npub (possibly embedded — e.g. "toobahlou_npub1abc...")
      const npubMatch = identifier.match(/(npub1[a-z0-9]{58})/i);
      if (npubMatch) {
        const npub = npubMatch[1];
        const hex = npubToHex(npub);
        if (hex) {
          const profile = await fetchPrimalProfile(hex);
          if (profile) {
            return {
              displayName: profile.display_name || profile.name || (npub.slice(0, 9) + '…' + npub.slice(-4)),
              avatarUrl: profile.picture || robohashAvatar(npub)
            };
          }
          return { displayName: npub.slice(0, 9) + '…' + npub.slice(-4), avatarUrl: robohashAvatar(npub) };
        }
        return { displayName: identifier, avatarUrl: null };
      }

      // NIP-05 (user@domain — must have a dot in the domain to avoid matching pure emails)
      if (identifier.includes('@') && /@[^@]+\.[^@]+$/.test(identifier)) {
        const hex = await resolveNIP05(identifier);
        if (hex) {
          const profile = await fetchPrimalProfile(hex);
          if (profile) {
            return {
              displayName: profile.display_name || profile.name || identifier,
              avatarUrl: profile.picture || robohashAvatar(hex)
            };
          }
          return { displayName: identifier, avatarUrl: robohashAvatar(hex) };
        }
        return { displayName: identifier, avatarUrl: null };
      }

      // Plain identifier — show as-is, no avatar
      return { displayName: identifier, avatarUrl: null };
    })();

    identityCache.set(identifier, promise);
    return promise;
  }

  function hasNostrId(s) {
    if (!s) return false;
    s = String(s);
    return /npub1[a-z0-9]{58}/i.test(s) || (s.includes('@') && /@[^@]+\.[^@]+$/.test(s));
  }

  function setUserDisplay(nameElId, avatarElId, primary, fallback) {
    const nameEl = document.getElementById(nameElId);
    const avatarEl = document.getElementById(avatarElId);
    const placeholderEl = avatarEl ? document.getElementById(avatarElId.replace(/Avatar$/, 'Placeholder')) : null;
    if (!nameEl) return;

    const card = avatarEl ? avatarEl.closest('.th-stat') : null;
    if (card) {
      delete card.dataset.identifier;
      delete card.dataset.identifierType;
      delete card.dataset.displayName;
      delete card.dataset.websiteUrl;
      card.classList.remove('th-clickable');
    }

    // Always store the original primary name + btcaddress on the card for hover tooltip
    if (card) {
      card.dataset.primary = primary || '';
      if (fallback) card.dataset.btcaddress = fallback;
      else delete card.dataset.btcaddress;
    }

    // _dot_ convention in the username takes priority for click destination
    if (card) {
      const websiteFromName = extractUrl(primary) || extractUrl(fallback);
      if (websiteFromName) {
        card.dataset.websiteUrl = websiteFromName;
        card.classList.add('th-clickable');
      }
    }

    // Inline name is always hidden — the placeholder (or resolved avatar) stands in for it.
    nameEl.textContent = displayName(primary || '');
    nameEl.style.display = 'none';
    if (avatarEl) {
      avatarEl.classList.remove('show');
      avatarEl.removeAttribute('src');
    }
    if (placeholderEl) {
      placeholderEl.classList.remove('hide');
    }

    if (!primary && !fallback) return;

    // Build resolution chain: primary first (if it has a nostr/twitter id), then fallback.
    const chain = [];
    if (primary && (hasNostrId(primary) || extractTwitterHandle(primary))) chain.push(primary);
    if (fallback && fallback !== primary && (hasNostrId(fallback) || extractTwitterHandle(fallback))) chain.push(fallback);

    if (chain.length === 0) return; // no nostr/twitter id — placeholder stays

    (async () => {
      for (const id of chain) {
        try {
          const resolved = await resolveIdentity(id);
          if (resolved && resolved.avatarUrl && avatarEl) {
            const safeAvatar = safeUrl(resolved.avatarUrl);
            if (!safeAvatar) continue; // reject javascript:/data:/etc. — fall through to next id
            avatarEl.onerror = function() {
              if (avatarEl.dataset.fellBack === '1') {
                // Even robohash failed — fall back to the hammer placeholder
                avatarEl.classList.remove('show');
                if (placeholderEl) placeholderEl.classList.remove('hide');
                return;
              }
              avatarEl.dataset.fellBack = '1';
              avatarEl.src = safeUrl(robohashAvatar(id));
            };
            avatarEl.dataset.fellBack = '0';
            avatarEl.src = safeAvatar;
            avatarEl.classList.add('show');
            if (placeholderEl) placeholderEl.classList.add('hide');

            // Record on the card so hover/click handlers can use it
            if (card) {
              card.dataset.identifier = id;
              card.dataset.displayName = resolved.displayName || id;
              card.dataset.avatarUrl = safeAvatar;
              card.dataset.identifierType =
                extractTwitterHandle(id) ? 'twitter' :
                (id.includes('@') && /@[^@]+\.[^@]+$/.test(id)) ? 'nip05' :
                'nostr';
              card.classList.add('th-clickable');
            }
            return;
          }
        } catch (e) {}
      }
      // Chain exhausted — placeholder stays visible
    })();
  }

  // ---------------- Hover tooltip + click navigation for right cards ----------------

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Whitelist URLs to http(s) only. Returns '' for javascript:/data:/vbscript:/etc.
  // Use everywhere a user-controlled value flows into href=, src=, or location calls.
  function safeUrl(u) {
    if (!u) return '';
    try {
      const parsed = new URL(String(u), location.origin);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') return parsed.href;
    } catch (_) {}
    return '';
  }

  // Detect "mywebsite_dot_com" / "mywebsiteDOTcom" / "my-dot-website" etc. patterns
  // in a username, mirroring index.html's extractUrl. Skips NIP-05 ids (contain @).
  function extractUrl(str) {
    if (!str) return null;
    str = String(str);
    if (str.includes('@')) return null;
    const normalized = str
      .replace(/[_\-]?dot[_\-]?/gi, '.')
      .replace(/DOT/g, '.');
    const match = normalized.match(/([a-zA-Z0-9][-a-zA-Z0-9]*\.)+[a-zA-Z]{2,}/);
    if (match) return 'https://' + match[0].toLowerCase();
    return null;
  }

  // Look up the resolved nostr profile for a card, if one is cached
  function getCardProfile(card) {
    const id = card && card.dataset && card.dataset.identifier;
    if (!id) return null;
    if (extractTwitterHandle(id)) return null;

    let hex = null;
    const npubMatch = id.match(/(npub1[a-z0-9]{58})/i);
    if (npubMatch) {
      hex = npubToHex(npubMatch[1]);
    } else if (id.includes('@')) {
      hex = idToPubkey.get(id) || null;
    }

    if (hex && profileCache.has(hex)) return profileCache.get(hex);
    return null;
  }

  // Resolve the best outbound URL for a card click.
  // Priority: _dot_ website convention in username > primal (nostr) > twitter.
  // Profile.website (from nostr metadata) is intentionally NOT used.
  function getCardUrl(card) {
    if (!card || !card.dataset) return null;

    if (card.dataset.websiteUrl) return card.dataset.websiteUrl;

    const id = card.dataset.identifier;
    if (!id) return null;
    const type = card.dataset.identifierType;

    if (type === 'twitter') {
      const handle = String(id).replace(/^@/, '');
      return 'https://twitter.com/' + encodeURIComponent(handle);
    }

    if (type === 'nostr' || type === 'nip05') {
      const npubMatch = id.match(/(npub1[a-z0-9]{58})/i);
      if (npubMatch) return 'https://primal.net/p/' + npubMatch[1];
      if (type === 'nip05') {
        const hex = idToPubkey.get(id);
        if (hex && window.NostrTools && window.NostrTools.nip19) {
          try {
            const npub = window.NostrTools.nip19.npubEncode(hex);
            return 'https://primal.net/p/' + npub;
          } catch (e) {}
        }
        return 'https://primal.net/p/' + encodeURIComponent(id);
      }
    }

    return null;
  }

  function buildHoverTipHtml(card) {
    const id = card.dataset.identifier;
    const primary = card.dataset.primary || '';

    // No resolved nostr/twitter id — just show the bare username
    if (!id) {
      if (!primary) return '';
      return `<div class="th-tip-head"><div class="th-tip-name"><div class="th-tip-display">${escapeHtml(displayName(primary))}</div></div></div>`;
    }

    const type = card.dataset.identifierType || '';
    const displayNameStr = card.dataset.displayName || id;
    const avatarUrl = card.dataset.avatarUrl || '';
    const profile = getCardProfile(card);

    const kindClass = (type === 'nostr' || type === 'nip05') ? 'nostr' : 'twitter';
    const kindLabel = (type === 'nostr' || type === 'nip05') ? 'NOSTR' : 'TWITTER';

    let html = '';
    html += '<div class="th-tip-head">';
    if (avatarUrl) {
      html += `<img class="th-tip-avatar ${kindClass}" src="${escapeHtml(safeUrl(avatarUrl))}" alt="">`;
    }
    html += '<div class="th-tip-name">';
    html += `<div class="th-tip-display">${escapeHtml(displayNameStr)}</div>`;
    html += `<div class="th-tip-kind ${kindClass}">${kindLabel}</div>`;
    html += '</div></div>';

    if (profile && profile.about) {
      html += `<div class="th-tip-bio">${escapeHtml(String(profile.about).trim())}</div>`;
    }

    if (profile && profile.nip05) {
      html += `<div class="th-tip-row nip05"><i class="fa-solid fa-circle-check ic" aria-hidden="true"></i>${escapeHtml(profile.nip05)}</div>`;
    }

    if (profile && profile.website) {
      const domain = String(profile.website).replace(/^https?:\/\//i, '').replace(/\/+$/, '');
      html += `<div class="th-tip-row website"><i class="fa-solid fa-globe ic" aria-hidden="true"></i>${escapeHtml(domain)}</div>`;
    }

    if (profile && profile.lud16) {
      html += `<div class="th-tip-row lightning"><i class="fa-solid fa-bolt ic" aria-hidden="true"></i>${escapeHtml(profile.lud16)}</div>`;
    }

    // Footer: HR + • <status> | N workers | best share X (best share omitted on the best-share card)
    const btcaddress = card.dataset.btcaddress || '';
    const activeCount = btcaddress ? userWorkerCount.get(btcaddress) : null;
    const totalCount = btcaddress ? userTotalWorkerCount.get(btcaddress) : null;
    const bestShare = btcaddress ? userBestShare.get(btcaddress) : null;
    const isBestShareCard = !!(card.querySelector && card.querySelector('#thHighestDifficulty'));

    const isActive = Number.isFinite(activeCount) && activeCount > 0;
    const workerCount = isActive ? activeCount : totalCount;
    const hasWorkers = Number.isFinite(workerCount) && workerCount > 0;
    const hasBest = !isBestShareCard && Number.isFinite(bestShare) && bestShare > 0;

    if (hasWorkers || hasBest || btcaddress) {
      let foot = '<div class="th-tip-foot">';
      foot += '<span class="dot' + (isActive ? '' : ' inactive') + '"></span>';
      foot += '<span>' + (isActive ? 'active' : 'inactive') + '</span>';
      if (hasWorkers) {
        const label = isActive
          ? (workerCount === 1 ? '1 active worker' : (workerCount + ' active workers'))
          : (workerCount === 1 ? '1 worker' : (workerCount + ' workers'));
        foot += '<span class="sep">|</span><span>' + label + '</span>';
      }
      if (hasBest) {
        foot += '<span class="sep">|</span><span>best share: ' + formatDifficultyCompact(bestShare) + '</span>';
      }
      foot += '</div>';
      html += foot;
    }

    return html;
  }

  function positionHoverTip(x, y) {
    const tip = document.getElementById('thHoverTip');
    if (!tip) return;
    const pad = 12;
    const rect = tip.getBoundingClientRect();
    let left = x + 14;
    let top = y + 14;
    if (left + rect.width + pad > window.innerWidth) left = x - rect.width - 14;
    if (top + rect.height + pad > window.innerHeight) top = y - rect.height - 14;
    left = Math.max(pad, Math.min(left, window.innerWidth - rect.width - pad));
    top = Math.max(pad, Math.min(top, window.innerHeight - rect.height - pad));
    tip.style.left = Math.round(left) + 'px';
    tip.style.top = Math.round(top) + 'px';
  }

  function showHoverTip(card, x, y) {
    const tip = document.getElementById('thHoverTip');
    if (!tip) return;
    const html = buildHoverTipHtml(card);
    if (!html) return;
    tip.innerHTML = html;
    // Make tip measurable before positioning
    tip.style.left = '0px';
    tip.style.top = '0px';
    tip.classList.add('show');
    positionHoverTip(x, y);
  }

  function hideHoverTip() {
    const tip = document.getElementById('thHoverTip');
    if (tip) tip.classList.remove('show');
  }

  function handleCardEnter(e) {
    const card = e.currentTarget;
    // Show tooltip for any right card with at least a primary name
    if (!card.dataset.identifier && !card.dataset.primary) return;
    showHoverTip(card, e.clientX, e.clientY);
  }

  function handleCardMove(e) {
    const card = e.currentTarget;
    if (!card.dataset.identifier && !card.dataset.primary) return;
    const tip = document.getElementById('thHoverTip');
    if (tip && tip.classList.contains('show')) {
      positionHoverTip(e.clientX, e.clientY);
    }
  }

  function handleCardLeave() {
    hideHoverTip();
  }

  function handleCardClick(e) {
    const card = e.currentTarget;
    if (!card.dataset.identifier && !card.dataset.websiteUrl) return;
    const url = getCardUrl(card);
    if (url) window.open(url, '_blank', 'noopener,noreferrer');
  }

  function setupCardInteractions() {
    const cards = document.querySelectorAll('#telehashTopbar .th-side.right .th-stat');
    cards.forEach(card => {
      card.addEventListener('mouseenter', handleCardEnter);
      card.addEventListener('mousemove', handleCardMove);
      card.addEventListener('mouseleave', handleCardLeave);
      card.addEventListener('click', handleCardClick);
    });
  }

  // Warm up the WebSocket so the first lookup isn't delayed by connect time
  ensurePrimalWs();

  // ---------------- Confetti ----------------

  function launchConfetti() {
    const layer = document.getElementById('telehashConfettiLayer');
    if (!layer) return;

    for (let i = 0; i < 140; i++) {
      const piece = document.createElement('span');
      piece.className = 'th-confetti';
      piece.style.left = (Math.random() * 100) + 'vw';
      piece.style.background = confettiColors[Math.floor(Math.random() * confettiColors.length)];
      piece.style.setProperty('--fall-ms', (1100 + Math.random() * 2200) + 'ms');
      piece.style.setProperty('--drift', (-180 + Math.random() * 360) + 'px');
      piece.style.animationDelay = (Math.random() * 450) + 'ms';

      layer.appendChild(piece);

      setTimeout(function() { piece.remove(); }, 4000);
    }
  }

  // ---------------- Boot ----------------

  injectTopbar();

  refreshStats();
  pollTelecache();
  pollLightning();

  setInterval(refreshStats, STATS_REFRESH_MS);
  setInterval(pollTelecache, TELECACHE_POLL_MS);
  setInterval(pollLightning, LIGHTNING_POLL_MS);

})();
