
# telehash topbar extension v8

Fixes:
- compact topbar, no bottom content clipping
- blue/glass/mono look closer to monitor/teledash
- centered telehash logo
- full-width BTC-raised progress bar toward 3.125 BTC goal
- full-page confetti layer
- discovers event endpoints by reading /monitor and /teledash source
- polls discovered/static endpoints for new payments and lightning chat
