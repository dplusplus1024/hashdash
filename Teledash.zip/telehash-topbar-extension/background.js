// Service worker that brokers audio playback through an offscreen document.
// Content scripts inherit the host page's autoplay policy; offscreen documents
// run in the extension's own context and bypass that restriction.

const OFFSCREEN_DOC_PATH = 'offscreen.html';

async function hasOffscreenDocument() {
  if (!chrome.runtime.getContexts) return false;
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOC_PATH)]
  });
  return contexts.length > 0;
}

async function ensureOffscreenDocument() {
  if (await hasOffscreenDocument()) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_DOC_PATH,
    reasons: ['AUDIO_PLAYBACK'],
    justification: 'Play a notification sound when a Telehash donation arrives.'
  });
}

// Only one URL is ever allowed to play through the offscreen audio document: our
// bundled sound. A compromised or impersonating content script (or any future
// extension code path) cannot use this message to make Audio() fetch arbitrary
// URLs (file://, intranet, etc.).
const ALLOWED_SOUND_URL = chrome.runtime.getURL('sound.mp3');

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  // Defense: reject messages that didn't originate from our own extension.
  if (sender && sender.id && sender.id !== chrome.runtime.id) return;

  if (msg && msg.type === 'playPaymentSound') {
    (async () => {
      try {
        // Ignore any caller-supplied URL and use our locked-down sound only.
        await ensureOffscreenDocument();
        chrome.runtime.sendMessage({ type: 'offscreen:play', url: ALLOWED_SOUND_URL });
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    })();
    return true; // async response
  }
});
