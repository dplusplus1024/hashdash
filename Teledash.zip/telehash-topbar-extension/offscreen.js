// Runs inside the extension's offscreen document — full audio privileges,
// no autoplay restriction inherited from any host page.

// Lock down playback to a single allowed URL — the bundled sound file. Even if
// the caller (background service worker) is ever tricked into forwarding an
// attacker-chosen URL, this layer rejects it.
const ALLOWED_SOUND_URL = chrome.runtime.getURL('sound.mp3');

let audio = null;

chrome.runtime.onMessage.addListener(function(msg, sender) {
  // Reject anything not coming from our own extension.
  if (sender && sender.id && sender.id !== chrome.runtime.id) return;
  if (!msg || msg.type !== 'offscreen:play') return;
  // Hard whitelist: only play the bundled sound, regardless of what URL was passed.
  if (msg.url !== ALLOWED_SOUND_URL) return;
  try {
    if (!audio) {
      audio = new Audio(ALLOWED_SOUND_URL);
      audio.preload = 'auto';
      audio.volume = 0.85;
    }
    audio.currentTime = 0;
    audio.play().catch(function(err) {
      console.warn('telehash offscreen audio play failed:', err);
    });
  } catch (e) {
    console.warn('telehash offscreen audio error:', e);
  }
});
